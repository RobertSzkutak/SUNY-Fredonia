#include <pic.h>
#include <stdio.h>
#include <stdlib.h>
#define _XTAL_FREQ 4000000
#define MAX_MESSAGE_SIZE 4

__CONFIG(UNPROTECT & BORDIS & MCLRDIS & PWRTEN & INTIO & WDTDIS);

char volts[MAX_MESSAGE_SIZE] = {'x','.','x','V'};  
char storage[MAX_MESSAGE_SIZE] = {'x','.','x','V'};
char whole;
unsigned short int bigvolt;

//sends a pulse down the RB6 line to tell the LCD to grab data
void pulse(void){

      RB6 = 1;

      RB6 = 0;          //pulse E line to write data

      __delay_ms(2);

}

//clears the LCD screen
void clearScreen() {
	RB7 = 0;
	__delay_ms(2);
	PORTC = 1;
	pulse();
	RB7 = 1;
}

//calls clearScreen and sends a new message
void sendMessage() {
	char i;
	
	clearScreen();
	for(i=0;i<MAX_MESSAGE_SIZE;i++) {
		PORTC = volts[i];
		pulse();
	}
}

//sets the propor volt positions and calls sendMessage()
void sendVolts(char *digit){
	char i;
	char refresh = 0;

	if(bigvolt > 100){       //if all digits present
		volts[0] = digit[0];
		volts[2] = digit[1];
	} else if(bigvolt > 10){ //if only 2 digits present
		volts[0] = '0';
		volts[2] = digit[0];
	} /*else {                 //if only one digit present
		volts[0] = '0';
		volts[2] = '0';
	}*/

	for(i=0;i<MAX_MESSAGE_SIZE;i++) {
		if(storage[i] != volts[i]) {
			refresh = 1;
			break;
		}	
	}
	
	if(refresh == 1){
		clearScreen();
		for(i=0;i<MAX_MESSAGE_SIZE;i++) {
			PORTC = volts[i];
			pulse();
		}
	}

	for(i=0;i<MAX_MESSAGE_SIZE;i++) {
		storage[i] = volts[i];
	}
	
}

char *compareVolts(char voltageHigh, char voltageLow){
	char tmpval = voltageHigh;
	char v[5];

	if((tmpval=(voltageHigh & 0b00000010)) == 0b00000010 ){
		bigvolt =bigvolt +250; // 2.5v
	}
	 tmpval = voltageHigh;
	if((tmpval=(voltageHigh & 0b00000001)) == 0b00000001 ){
		bigvolt =bigvolt +125; //1.5v
	}
	if((tmpval=(voltageLow & 0b10000000)) == 0b10000000 ){
		bigvolt =bigvolt +63; //.63v
	}	
	if((tmpval=(voltageLow & 0b01000000)) == 0b01000000 ){
		bigvolt =bigvolt +31; //.31v
	}
	if((tmpval=(voltageLow & 0b00100000)) == 0b00100000 ){
		bigvolt =bigvolt +15; //.15v
	}
	if((tmpval=(voltageLow & 0b00010000)) == 0b00010000 ){
		bigvolt =bigvolt +8; //.08v
	}
	if((tmpval=(voltageLow & 0b00001000)) == 0b00001000 ){
		bigvolt =bigvolt +4; //.04v
	}
	if((tmpval=(voltageLow & 0b00000100)) == 0b00000100 ){
		bigvolt =bigvolt +2; //.02v
	}
	if((tmpval=(voltageLow & 0b00000010)) == 0b00000010 ){
		bigvolt = bigvolt + 1; //.01v
	}
	
	if(bigvolt == 499)
		if((tmpval=(voltageLow & 0b00000001)) == 0b00000001 ){
		bigvolt = bigvolt + 1; // this adds the final tenth value if all bits set
	}

	sprintf(v,"%d",bigvolt); //turn the integer value of the volts into a char array
	return v;
}

//checks the current voltage, calls the compare volts and send volts
void interrupt isr() {
	ADIF = 0;
	bigvolt = 0;
	char voltageHigh = ADRESH; // copy the value to avoid corruption on interrupt
	char voltageLow  = ADRESL; // copt the value to avoid corruption on interrupt
	char *volt;
	volt = compareVolts(voltageHigh, voltageLow);
	sendVolts(volt);
	__delay_ms(30);
	GODONE = 1;
}
 

void initLCD(void){ 
	RB6 = 0;          //set E low  (disable write)
	RB7 = 0;          //set RS low (command)

	__delay_ms(125);  //wait for display to power up

	PORTC = 0x38;  //set 8 bit, 2 lines, 5x7 matrix
	pulse();
	PORTC = 0x0F;           //display on, cursor on, cursor blinking
	pulse();
	PORTC = 1;  //clear display or 0b00000001 or 0x01
	pulse();
	RB7 = 1;          //switch to data mode

}

//set up comparator on pin RA2 and AN2
void initComparator() {
	GIE     = 1;
	ADIE    = 1;

	INTCON  = 0b11000000;
	ADCON0  = 0b10001001;                  
	ADCON1  = 0b00010000;
	GODONE  = 1;
}

 void main(){

	TRISC  = 0;
	TRISB  = 0;
	TRISA = 0b00000100;

	ANSEL = 0b00000100;
	ANSELH = 0;
	__delay_ms(5);

	initLCD();    //set up LCD settings
	__delay_ms(5);

	initComparator(); //setup comparator settings

	while (1); // keep code running, interrupts handle function calls
}